import React, { useState } from 'react';
import axios from 'axios';
import ManagePosters from './ManagePosters';

const ManagePayments=()=>{
    return (
        <div>
            <h2> Manage Payments </h2>
        </div>
    )
}

export default ManagePayments;