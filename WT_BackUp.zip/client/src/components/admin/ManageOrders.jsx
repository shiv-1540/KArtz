import React, { useState } from 'react';
import axios from 'axios';

const ManageOrders=()=>{
    return (
        <div>
            <h2> Manage Orders</h2>
        </div>
    )
}

export default ManageOrders;