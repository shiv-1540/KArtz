import React, { useState } from 'react';
import axios from 'axios';

const Admindash=()=>{
    return (
        <div className='text-gray-500'>
          <h1>AdminDashboard</h1>
        </div>
    )
}

export default Admindash;