const {v2} =require("cloudinary")

v2.config({
    api_key:"585855262798416",
    cloud_name:"dgl4afjkb",
    api_secret:"O49iSVjUBqCh9UqhZFkUv7H3CqI"
})


module.exports=v2;